This is a small project that I made for college second year, you can hire, fire, check salary, change salary, Sort employees based on years of work, hours worked per month, salary.

the information gets added to a file that you can use at any time to check or change anything about a particular employee 